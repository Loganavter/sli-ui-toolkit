"""Reusable PyQt UI primitives."""

