"""Dropdown menu widget used by Button when menu mode is active."""

from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QEvent, QPoint, QPropertyAnimation, QRect, QSize, Qt, Signal
from PySide6.QtGui import QAction, QBrush, QColor, QFontMetrics, QGuiApplication, QPainter, QPen
from PySide6.QtWidgets import QApplication, QVBoxLayout, QWidget

from sli_ui_toolkit.theme import ThemeManager
from sli_ui_toolkit.ui.in_window_surface import (
    attach_in_window_widget,
    paint_shadowed_surface,
)
from sli_ui_toolkit.ui.widgets.buttons.button import Button
from sli_ui_toolkit.ui.widgets.buttons.layers import RippleLayer
from sli_ui_toolkit.ui.widgets.buttons.layers._base import Layer
from sli_ui_toolkit.ui.widgets.buttons.state import ButtonState
from sli_ui_toolkit.ui.widgets.helpers.icon_pixmap import normalized_icon_pixmap


class _MenuItemBgLayer(Layer):
    def applies(self, ctx) -> bool:
        widget = ctx.widget
        states = ctx.effective_states
        return (
            widget._is_current
            or ButtonState.HOVERED in states
            or ButtonState.PRESSED in states
        )

    def draw(self, ctx, tm: ThemeManager) -> None:
        rect = ctx.rect.toRect().adjusted(2, 2, -2, -2)
        p = ctx.painter
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(tm.get_color("list_item.background.hover")))
        p.drawRoundedRect(rect, 4, 4)


class _MenuItemContentLayer(Layer):
    def draw(self, ctx, tm: ThemeManager) -> None:
        widget = ctx.widget
        p = ctx.painter
        rect = ctx.rect.toRect()
        text_color = widget._foreground_color or tm.get_color("dialog.text")
        if widget._check_icon:
            icon_rect = QRect(10, (rect.height() - 20) // 2, 20, 20)
            p.drawPixmap(icon_rect, widget._check_icon)
        p.setPen(QPen(text_color))
        p.setFont(widget.font())
        text_x = 40 if widget._check_icon else 12
        text_y = rect.center().y() + 5
        p.drawText(text_x, text_y, widget._text)


class _MenuItem(Button):
    def __init__(self, text: str, is_current: bool, parent=None):
        super().__init__(
            text="",
            size=(0, 40),
            corner_radius=4,
            layers=[_MenuItemBgLayer(), RippleLayer(), _MenuItemContentLayer()],
            parent=parent,
        )
        self._text = text
        self._is_current = is_current
        self._check_icon = (
            normalized_icon_pixmap("check", 20) if is_current else None
        )
        self._foreground_color = None

    def event(self, event):
        if event.type() == QEvent.Type.DynamicPropertyChange:
            name = event.propertyName().data().decode("utf-8", errors="ignore")
            if name == "foregroundColor":
                self._foreground_color = (
                    self.property("foregroundColor") or self._foreground_color
                )
                self.update()
        return super().event(event)

    def set_current(self, is_current: bool):
        self._is_current = is_current
        self._check_icon = normalized_icon_pixmap("check", 20) if is_current else None
        self.update()

class DropdownMenu(QWidget):
    item_selected = Signal(QAction)

    MARGIN = 8
    SHADOW_RADIUS = 8
    CONTENT_RADIUS = 8
    DROP_OFFSET_PX = 80
    APPEAR_EXTRA_Y = 6
    _move_duration_ms = 240
    _move_easing = QEasingCurve.Type.OutQuad

    def __init__(self, parent=None):
        if parent is None:
            raise ValueError("DropdownMenu requires an in-window parent widget")
        super().__init__(parent)
        self.setWindowFlags(Qt.WindowType.Widget)
        self._owner_button = parent
        self._actions = []
        self._menu_items = []
        self._current_index = -1
        self._anim = None
        self.overlay_layer = attach_in_window_widget(self, parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(8, 8, 8, 8)
        self.container_widget = QWidget(self)
        self.container_widget.setObjectName("menuContainer")
        self.container_widget.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.main_layout.addWidget(self.container_widget)
        self.container_layout = QVBoxLayout(self.container_widget)
        self.container_layout.setContentsMargins(4, 4, 4, 4)
        self.container_layout.setSpacing(2)
        self.content_widget = QWidget(self.container_widget)
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(0, 0, 0, 0)
        self.content_layout.setSpacing(2)
        self.container_layout.addWidget(self.content_widget)
        self._global_filter_installed = False
        self.hide()

    def _install_outside_click_filter(self):
        if self._global_filter_installed:
            return
        app = QApplication.instance()
        if app is not None:
            app.installEventFilter(self)
            self._global_filter_installed = True

    def _remove_outside_click_filter(self):
        if not getattr(self, "_global_filter_installed", False):
            return
        app = QApplication.instance()
        if app is not None:
            app.removeEventFilter(self)
        self._global_filter_installed = False

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.MouseButtonPress and self.isVisible():
            try:
                global_pos = event.globalPosition().toPoint()
            except AttributeError:
                global_pos = event.globalPos()
            # Click is outside the menu and outside the owner button → close.
            menu_top_left = self.mapToGlobal(QPoint(0, 0))
            menu_rect = QRect(menu_top_left, self.size())
            inside_menu = menu_rect.contains(global_pos)
            inside_owner = False
            if self._owner_button is not None:
                try:
                    owner_top_left = self._owner_button.mapToGlobal(QPoint(0, 0))
                    inside_owner = QRect(owner_top_left, self._owner_button.size()).contains(global_pos)
                except RuntimeError:
                    pass
            if not inside_menu and not inside_owner:
                self.hide()
        return False

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        paint_shadowed_surface(
            painter,
            self.container_widget.geometry(),
            shadow_radius=self.SHADOW_RADIUS,
            corner_radius=self.CONTENT_RADIUS,
        )
        tm = ThemeManager.get_instance()
        rect = self.container_widget.geometry()
        painter.setBrush(QBrush(tm.get_color("flyout.background")))
        painter.setPen(QPen(tm.get_color("flyout.border"), 1))
        painter.drawRoundedRect(rect, self.CONTENT_RADIUS, self.CONTENT_RADIUS)
        painter.end()

    def _ensure_overlay_parent(self, anchor_widget: QWidget):
        if self.overlay_layer is None:
            self.overlay_layer = attach_in_window_widget(self, anchor_widget)
        if self.overlay_layer is not None and self.parentWidget() is not self.overlay_layer.host:
            was_visible = self.isVisible()
            self.overlay_layer.attach(self)
            if was_visible:
                self.show()
                self.raise_()
            return

        if self.overlay_layer is None:
            window = anchor_widget.window()
            if window is not None and self.parentWidget() is not window:
                was_visible = self.isVisible()
                self.setParent(window)
                if was_visible:
                    self.show()
                    self.raise_()

    def set_actions(self, actions: list[tuple[str, any]]):
        self._actions = actions
        self._current_index = -1

    def set_current_by_data(self, data: any):
        for i, (_, action_data) in enumerate(self._actions):
            if action_data == data:
                self._current_index = i
                break

    def show_for_anchor(self, anchor_widget: QWidget):
        self._ensure_overlay_parent(anchor_widget)
        if not self._actions:
            return
        if self._anim:
            self._anim.stop()
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._menu_items.clear()
        anchor_width = max(0, int(anchor_widget.width()))
        metrics = QFontMetrics(self.font())
        check_icon_space = 28 if self._current_index >= 0 else 0
        longest_text_width = max(
            (metrics.horizontalAdvance(str(text)) for text, _data in self._actions),
            default=0,
        )
        content_width = longest_text_width + check_icon_space + 24
        max_width = max(40, anchor_width - 16, content_width)
        for i, (text, data) in enumerate(self._actions):
            item = _MenuItem(text, i == self._current_index, self.content_widget)
            item.clicked.connect(lambda checked=False, idx=i: self._on_item_clicked(idx))
            self._menu_items.append(item)
            self.content_layout.addWidget(item)
        item_height = 40
        content_height = len(self._actions) * item_height + max(0, len(self._actions) - 1) * self.content_layout.spacing()
        container_height = content_height + 8
        self.container_widget.setFixedSize(max_width, container_height)
        self.setFixedSize(max_width + 16, container_height + 16)
        use_overlay_coords = self.overlay_layer is not None
        if use_overlay_coords:
            anchor_rect = self.overlay_layer.anchor_rect(anchor_widget)
        else:
            parent = self.parentWidget()
            anchor_top_left = anchor_widget.mapTo(parent, QPoint(0, 0)) if parent is not None else anchor_widget.mapToGlobal(QPoint(0, 0))
            anchor_rect = QRect(anchor_top_left, anchor_widget.size())
        final_pos = QPoint(anchor_rect.x() - 8, anchor_rect.bottom() - 4 + self.APPEAR_EXTRA_Y)
        start_pos = QPoint(final_pos.x(), final_pos.y() - self.DROP_OFFSET_PX)
        if use_overlay_coords:
            final_rect = self.overlay_layer.clamp_rect(QRect(final_pos, QSize(max_width + 16, container_height + 16)))
            if final_rect.width() < max_width + 16:
                max_width = max(40, final_rect.width() - 16)
                self.container_widget.setFixedSize(max_width, container_height)
                self.setFixedSize(max_width + 16, container_height + 16)
                final_rect = QRect(final_rect.topLeft(), QSize(max_width + 16, container_height + 16))
            final_pos = final_rect.topLeft()
            start_pos = QPoint(final_pos.x(), final_pos.y() - self.DROP_OFFSET_PX)
        else:
            parent = self.parentWidget()
            if parent is not None:
                bounds = parent.rect()
                final_pos.setX(max(bounds.left(), min(final_pos.x(), bounds.right() - (max_width + 16))))
                final_pos.setY(max(bounds.top(), min(final_pos.y(), bounds.bottom() - (container_height + 16))))
                start_pos = QPoint(final_pos.x(), final_pos.y() - self.DROP_OFFSET_PX)
            else:
                try:
                    screen = QGuiApplication.screenAt(anchor_widget.mapToGlobal(QPoint(0, 0)))
                    if screen:
                        avail = screen.availableGeometry()
                        final_pos.setX(max(avail.left(), min(final_pos.x(), avail.right() - (max_width + 16))))
                        final_pos.setY(max(avail.top(), min(final_pos.y(), avail.bottom() - (container_height + 16))))
                        start_pos = QPoint(final_pos.x(), final_pos.y() - self.DROP_OFFSET_PX)
                except Exception:
                    pass
        self.move(start_pos)
        self.show()
        self.raise_()
        self._install_outside_click_filter()
        anim_pos = QPropertyAnimation(self, b"pos", self)
        anim_pos.setDuration(self._move_duration_ms)
        anim_pos.setStartValue(start_pos)
        anim_pos.setEndValue(final_pos)
        anim_pos.setEasingCurve(self._move_easing)
        anim_pos.finished.connect(self._on_animation_finished)
        self._anim = anim_pos
        anim_pos.start()

    def _on_animation_finished(self):
        if self._anim:
            anim_obj = self._anim
            self._anim = None
            anim_obj.deleteLater()

    def _on_item_clicked(self, index: int):
        if 0 <= index < len(self._actions):
            _, data = self._actions[index]
            action = QAction(self)
            action.setData(data)
            self.item_selected.emit(action)
        self.hide()

    def hideEvent(self, event):
        if self._anim:
            self._anim.stop()
        self._remove_outside_click_filter()
        if self._owner_button is not None and hasattr(self._owner_button, "_menu_visible"):
            self._owner_button._menu_visible = False
        super().hideEvent(event)
